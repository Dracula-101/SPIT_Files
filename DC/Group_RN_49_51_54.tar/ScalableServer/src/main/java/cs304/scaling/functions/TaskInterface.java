package cs304.scaling.functions;


public interface TaskInterface {
    void onTask();
}
